"use client"

import { useEffect } from "react"

export function FontLoader() {
  useEffect(() => {
    // Ensure fonts are loaded properly
    if (typeof document !== "undefined") {
      // Add font-display: swap to any dynamically loaded fonts
      const style = document.createElement("style")
      style.textContent = `
        * {
          font-family: system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif !important;
        }
        
        .font-mono {
          font-family: ui-monospace, SFMono-Regular, "SF Mono", Consolas, "Liberation Mono", Menlo, monospace !important;
        }
      `
      document.head.appendChild(style)

      return () => {
        if (document.head.contains(style)) {
          document.head.removeChild(style)
        }
      }
    }
  }, [])

  return null
}
