import React from "react"

interface PrayerRowProps {
  prayer: {
    name: string
    begins: string
    jamat: string
    icon: string
  }
  formatTime: (time: string, name?: string) => string
}

// Memoized prayer row component to prevent unnecessary re-renders
export const PrayerRow = React.memo(({ prayer, formatTime }: PrayerRowProps) => {
  return (
    <div className="flex justify-between items-center p-4 rounded-xl transition-all bg-white/10 hover:bg-white/20">
      <div className="flex items-center gap-2 font-semibold">
        <span>{prayer.icon}</span>
        <span>{prayer.name}</span>
      </div>
      <div className="flex gap-8 text-right">
        <span className="w-16 text-sm text-center">{formatTime(prayer.begins, prayer.name)}</span>
        <span className="w-16 font-semibold text-center">
          {prayer.jamat ? formatTime(prayer.jamat, prayer.name) : "—"}
        </span>
      </div>
    </div>
  )
})

PrayerRow.displayName = "PrayerRow"
