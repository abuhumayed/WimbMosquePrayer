"use client"

import { useState, useEffect } from "react"
import { Download, X } from "lucide-react"

interface BeforeInstallPromptEvent extends Event {
  readonly platforms: string[]
  readonly userChoice: Promise<{
    outcome: "accepted" | "dismissed"
    platform: string
  }>
  prompt(): Promise<void>
}

export function InstallPrompt() {
  const [deferredPrompt, setDeferredPrompt] = useState<BeforeInstallPromptEvent | null>(null)
  const [showInstallPrompt, setShowInstallPrompt] = useState(false)
  const [isIOS, setIsIOS] = useState(false)
  const [isStandalone, setIsStandalone] = useState(false)
  const [isLoading, setIsLoading] = useState(false)

  useEffect(() => {
    // Check if we're in a browser environment
    if (typeof window === "undefined") return

    try {
      // Check if device is iOS
      const userAgent = navigator.userAgent || ""
      const iOS = /iPad|iPhone|iPod/.test(userAgent)
      setIsIOS(iOS)

      // Check if app is already installed (standalone mode)
      const standalone =
        window.matchMedia("(display-mode: standalone)").matches || (window.navigator as any)?.standalone === true
      setIsStandalone(standalone)

      // Listen for the beforeinstallprompt event
      const handleBeforeInstallPrompt = (e: Event): void => {
        e.preventDefault()
        setDeferredPrompt(e as BeforeInstallPromptEvent)

        // Don't show immediately, wait a bit
        setTimeout(() => {
          const dismissed = sessionStorage.getItem("installPromptDismissed")
          if (!dismissed) {
            setShowInstallPrompt(true)
          }
        }, 5000)
      }

      window.addEventListener("beforeinstallprompt", handleBeforeInstallPrompt)

      // For iOS, show install prompt after a delay if not already installed
      if (iOS && !standalone) {
        const timer = setTimeout(() => {
          const dismissed = sessionStorage.getItem("installPromptDismissed")
          if (!dismissed) {
            setShowInstallPrompt(true)
          }
        }, 8000) // Show after 8 seconds on iOS

        return () => {
          clearTimeout(timer)
          window.removeEventListener("beforeinstallprompt", handleBeforeInstallPrompt)
        }
      }

      return () => {
        window.removeEventListener("beforeinstallprompt", handleBeforeInstallPrompt)
      }
    } catch (error) {
      console.log("Install prompt setup error:", error)
      return
    }
  }, [])

  const handleInstallClick = async (): Promise<void> => {
    if (!deferredPrompt) return

    setIsLoading(true)

    try {
      await deferredPrompt.prompt()
      const { outcome } = await deferredPrompt.userChoice

      if (outcome === "accepted") {
        setDeferredPrompt(null)
        setShowInstallPrompt(false)
        sessionStorage.setItem("installPromptDismissed", "true")
      }
    } catch (error) {
      console.log("Install prompt error:", error)
    } finally {
      setIsLoading(false)
    }
  }

  const handleDismiss = (): void => {
    setShowInstallPrompt(false)
    sessionStorage.setItem("installPromptDismissed", "true")
  }

  // Don't show if already installed, user dismissed, or in standalone mode
  if (isStandalone || !showInstallPrompt) {
    return null
  }

  return (
    <div className="fixed bottom-4 left-4 right-4 z-50 mx-auto max-w-md">
      <div className="bg-white dark:bg-gray-800 rounded-xl shadow-lg border border-gray-200 dark:border-gray-700 p-4 animate-slide-up">
        <div className="flex items-start justify-between mb-3">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 bg-gradient-to-br from-amber-400 to-emerald-500 rounded-lg flex items-center justify-center shadow-sm">
              <svg viewBox="0 0 120 120" className="w-6 h-6">
                <path d="M60 18 C45 18 35 28 35 42 L85 42 C85 28 75 18 60 18 Z" fill="white" />
                <path d="M60 10 L52 25 L68 25 Z" fill="white" />
                <rect x="40" y="42" width="8" height="30" fill="white" opacity="0.8" />
                <rect x="72" y="42" width="8" height="30" fill="white" opacity="0.8" />
                <path d="M25 72 L45 72 L55 92 L35 92 Z" fill="white" />
                <path d="M75 72 L95 72 L85 92 L65 92 Z" fill="white" />
                <path d="M52 82 L68 82 L65 92 L55 92 Z" fill="white" />
              </svg>
            </div>
            <div>
              <h3 className="font-semibold text-gray-900 dark:text-white text-sm">Install Prayer Times</h3>
              <p className="text-xs text-gray-600 dark:text-gray-300">Quick access from your home screen</p>
            </div>
          </div>
          <button
            onClick={handleDismiss}
            className="text-gray-400 hover:text-gray-600 dark:hover:text-gray-300 p-1"
            aria-label="Dismiss"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {isIOS ? (
          <div className="space-y-3">
            <p className="text-xs text-gray-600 dark:text-gray-300 font-medium">To install on your iPhone/iPad:</p>
            <div className="bg-blue-50 dark:bg-blue-900/20 rounded-lg p-3">
              <ol className="text-xs text-gray-700 dark:text-gray-300 space-y-2">
                <li className="flex items-center space-x-2">
                  <span className="flex-shrink-0 w-5 h-5 bg-blue-500 text-white rounded-full flex items-center justify-center text-xs font-bold">
                    1
                  </span>
                  <span>Tap the Share button in Safari</span>
                  <div className="w-6 h-6 bg-blue-500 rounded text-white text-center text-xs leading-6">↗</div>
                </li>
                <li className="flex items-center space-x-2">
                  <span className="flex-shrink-0 w-5 h-5 bg-blue-500 text-white rounded-full flex items-center justify-center text-xs font-bold">
                    2
                  </span>
                  <span>Scroll down and tap "Add to Home Screen"</span>
                </li>
                <li className="flex items-center space-x-2">
                  <span className="flex-shrink-0 w-5 h-5 bg-blue-500 text-white rounded-full flex items-center justify-center text-xs font-bold">
                    3
                  </span>
                  <span>Tap "Add" to confirm</span>
                </li>
              </ol>
            </div>
          </div>
        ) : (
          <button
            onClick={handleInstallClick}
            disabled={isLoading}
            className="w-full bg-gradient-to-r from-emerald-600 to-emerald-700 hover:from-emerald-700 hover:to-emerald-800 disabled:opacity-50 text-white font-medium py-3 px-4 rounded-lg flex items-center justify-center space-x-2 transition-all duration-200 shadow-sm"
          >
            {isLoading ? (
              <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
            ) : (
              <Download className="w-4 h-4" />
            )}
            <span>{isLoading ? "Installing..." : "Add to Home Screen"}</span>
          </button>
        )}
      </div>
    </div>
  )
}
