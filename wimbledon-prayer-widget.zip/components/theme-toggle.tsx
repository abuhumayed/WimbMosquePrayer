"use client"

import { Moon, Sun, Download, Plus } from "lucide-react"
import { useEffect, useState } from "react"

interface ThemeToggleProps {
  onThemeChange?: (isDark: boolean) => void
}

interface BeforeInstallPromptEvent extends Event {
  readonly platforms: string[]
  readonly userChoice: Promise<{
    outcome: "accepted" | "dismissed"
    platform: string
  }>
  prompt(): Promise<void>
}

export function ThemeToggle({ onThemeChange }: ThemeToggleProps) {
  const [isDark, setIsDark] = useState(false)
  const [deferredPrompt, setDeferredPrompt] = useState<BeforeInstallPromptEvent | null>(null)
  const [showInstallButton, setShowInstallButton] = useState(false)
  const [isIOS, setIsIOS] = useState(false)
  const [isStandalone, setIsStandalone] = useState(false)
  const [canInstall, setCanInstall] = useState(false)

  useEffect(() => {
    // Theme setup
    const savedTheme = localStorage.getItem("theme")
    const prefersDark = window.matchMedia("(prefers-color-scheme: dark)").matches
    const shouldBeDark = savedTheme === "dark" || (!savedTheme && prefersDark)

    setIsDark(shouldBeDark)
    document.documentElement.classList.toggle("dark", shouldBeDark)
    onThemeChange?.(shouldBeDark)

    // Device detection
    const userAgent = navigator.userAgent || ""
    const iOS = /iPad|iPhone|iPod/.test(userAgent)
    const isChrome = /Chrome/.test(userAgent) && !/Edg/.test(userAgent)
    const isEdge = /Edg/.test(userAgent)
    const isSafari = /Safari/.test(userAgent) && !isChrome && !isEdge

    setIsIOS(iOS)

    // Check if already installed
    const standalone =
      window.matchMedia("(display-mode: standalone)").matches || (window.navigator as any)?.standalone === true

    setIsStandalone(standalone)

    console.log("PWA Detection:", {
      iOS,
      isChrome,
      isSafari,
      isEdge,
      standalone,
      userAgent: userAgent.substring(0, 50) + "...",
    })

    // Show install button if not already installed
    if (!standalone) {
      setShowInstallButton(true)
      console.log("Install button will be shown")
    }

    // Listen for the beforeinstallprompt event (Chrome/Edge)
    const handleBeforeInstallPrompt = (e: Event) => {
      console.log("🎉 beforeinstallprompt event fired!")
      e.preventDefault()
      setDeferredPrompt(e as BeforeInstallPromptEvent)
      setCanInstall(true)
      setShowInstallButton(true)
    }

    window.addEventListener("beforeinstallprompt", handleBeforeInstallPrompt)

    // For browsers that support it, check if app is installable
    if ("getInstalledRelatedApps" in navigator) {
      ;(navigator as any)
        .getInstalledRelatedApps()
        .then((relatedApps: any[]) => {
          console.log("Related apps:", relatedApps)
          if (relatedApps.length === 0) {
            setCanInstall(true)
          }
        })
        .catch((error: any) => {
          console.log("getInstalledRelatedApps error:", error)
        })
    }

    return () => {
      window.removeEventListener("beforeinstallprompt", handleBeforeInstallPrompt)
    }
  }, [onThemeChange])

  const toggleTheme = (): void => {
    const newIsDark = !isDark
    setIsDark(newIsDark)
    localStorage.setItem("theme", newIsDark ? "dark" : "light")
    document.documentElement.classList.toggle("dark", newIsDark)
    onThemeChange?.(newIsDark)
  }

  const handleInstallClick = async (): Promise<void> => {
    console.log("🚀 Install button clicked!")
    console.log("Deferred prompt available:", !!deferredPrompt)
    console.log("Is iOS:", isIOS)
    console.log("Can install:", canInstall)

    if (isIOS) {
      // iOS Safari instructions
      const message = `📱 Install Prayer Times App on iOS:

1️⃣ Tap the Share button (⬆️) at the bottom of Safari
2️⃣ Scroll down and tap "Add to Home Screen"
3️⃣ Tap "Add" to confirm

The app will appear on your home screen with the mosque logo! 🕌`

      alert(message)
      return
    }

    if (deferredPrompt) {
      console.log("✅ Using native install prompt")
      try {
        // Show the native install prompt
        await deferredPrompt.prompt()

        // Wait for the user's response
        const { outcome } = await deferredPrompt.userChoice
        console.log("Install outcome:", outcome)

        if (outcome === "accepted") {
          console.log("🎉 User accepted the install prompt")
          setDeferredPrompt(null)
          setShowInstallButton(false)
          setCanInstall(false)
        } else {
          console.log("❌ User dismissed the install prompt")
        }
      } catch (error) {
        console.error("Install prompt error:", error)
        showFallbackInstructions()
      }
    } else {
      console.log("⚠️ No native prompt available, showing instructions")
      showFallbackInstructions()
    }
  }

  const showFallbackInstructions = () => {
    const userAgent = navigator.userAgent || ""
    let instructions = "📱 Install Prayer Times App:\n\n"

    if (/Chrome/.test(userAgent)) {
      instructions += "🔍 Look for the install icon (⊕) in the address bar\n"
      instructions += "📍 Or go to Chrome menu → Install Prayer Times\n"
    } else if (/Firefox/.test(userAgent)) {
      instructions += "📍 Firefox menu → Install this site as an app\n"
    } else if (/Safari/.test(userAgent)) {
      instructions += "📍 Share button → Add to Home Screen\n"
    } else if (/Edg/.test(userAgent)) {
      instructions += "🔍 Look for the install icon (⊕) in the address bar\n"
      instructions += "📍 Or go to Edge menu → Apps → Install Prayer Times\n"
    } else {
      instructions += "📍 Look for 'Install' or 'Add to Home Screen' in your browser menu\n"
    }

    instructions += "\n🕌 The app will show the mosque logo on your home screen!"

    alert(instructions)
  }

  return (
    <div className="flex items-center space-x-3">
      {/* Install Button - Always show if not standalone */}
      {showInstallButton && (
        <button
          onClick={handleInstallClick}
          className={`p-2 rounded-full transition-all duration-200 focus:outline-none focus:ring-2 focus:ring-white/50 ${
            canInstall || deferredPrompt
              ? "bg-amber-500/80 hover:bg-amber-400/90 animate-pulse"
              : "bg-white/20 hover:bg-white/30"
          }`}
          aria-label="Add to Home Screen"
          title={`Add to Home Screen ${canInstall ? "(Ready to install!)" : ""}`}
        >
          {canInstall || deferredPrompt ? (
            <Plus className="h-4 w-4 text-white" />
          ) : (
            <Download className="h-4 w-4 text-white" />
          )}
        </button>
      )}

      {/* Theme Toggle */}
      <button
        onClick={toggleTheme}
        className="relative inline-flex h-6 w-11 items-center rounded-full bg-gray-200 transition-colors focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 dark:bg-gray-700"
        role="switch"
        aria-checked={isDark}
        aria-label="Toggle dark mode"
      >
        <span
          className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform ${
            isDark ? "translate-x-6" : "translate-x-1"
          }`}
        >
          {isDark ? (
            <Moon className="h-3 w-3 text-gray-700 m-0.5" />
          ) : (
            <Sun className="h-3 w-3 text-yellow-500 m-0.5" />
          )}
        </span>
      </button>
    </div>
  )
}
