"use client"

import { useEffect } from "react"

export function IconGenerator() {
  useEffect(() => {
    // Generate icons using the official mosque logo design
    const generateIcon = (size: number): string => {
      const canvas = document.createElement("canvas")
      canvas.width = size
      canvas.height = size
      const ctx = canvas.getContext("2d")

      if (!ctx) return ""

      // White background for better visibility
      ctx.fillStyle = "#ffffff"
      ctx.fillRect(0, 0, size, size)

      const scale = size / 120
      const centerX = size / 2
      const centerY = size / 2

      // Golden dome (top)
      ctx.fillStyle = "#F59E0B" // amber-500
      ctx.beginPath()
      ctx.arc(centerX, centerY - 25 * scale, 18 * scale, 0, Math.PI, true)
      ctx.fill()

      // Dome top point
      ctx.beginPath()
      ctx.moveTo(centerX, centerY - 43 * scale)
      ctx.lineTo(centerX - 8 * scale, centerY - 25 * scale)
      ctx.lineTo(centerX + 8 * scale, centerY - 25 * scale)
      ctx.closePath()
      ctx.fill()

      // White pillars/columns
      ctx.fillStyle = "#E5E7EB" // gray-200
      ctx.strokeStyle = "#9CA3AF" // gray-400
      ctx.lineWidth = 1 * scale

      // Left pillar
      ctx.fillRect(centerX - 20 * scale, centerY - 25 * scale, 8 * scale, 30 * scale)
      ctx.strokeRect(centerX - 20 * scale, centerY - 25 * scale, 8 * scale, 30 * scale)

      // Right pillar
      ctx.fillRect(centerX + 12 * scale, centerY - 25 * scale, 8 * scale, 30 * scale)
      ctx.strokeRect(centerX + 12 * scale, centerY - 25 * scale, 8 * scale, 30 * scale)

      // Green geometric base (W-like shape)
      ctx.fillStyle = "#10B981" // emerald-500

      // Left green section
      ctx.beginPath()
      ctx.moveTo(centerX - 35 * scale, centerY + 5 * scale)
      ctx.lineTo(centerX - 15 * scale, centerY + 5 * scale)
      ctx.lineTo(centerX - 5 * scale, centerY + 25 * scale)
      ctx.lineTo(centerX - 25 * scale, centerY + 25 * scale)
      ctx.closePath()
      ctx.fill()

      // Right green section
      ctx.beginPath()
      ctx.moveTo(centerX + 15 * scale, centerY + 5 * scale)
      ctx.lineTo(centerX + 35 * scale, centerY + 5 * scale)
      ctx.lineTo(centerX + 25 * scale, centerY + 25 * scale)
      ctx.lineTo(centerX + 5 * scale, centerY + 25 * scale)
      ctx.closePath()
      ctx.fill()

      // Center connecting element
      ctx.beginPath()
      ctx.moveTo(centerX - 8 * scale, centerY + 15 * scale)
      ctx.lineTo(centerX + 8 * scale, centerY + 15 * scale)
      ctx.lineTo(centerX + 5 * scale, centerY + 25 * scale)
      ctx.lineTo(centerX - 5 * scale, centerY + 25 * scale)
      ctx.closePath()
      ctx.fill()

      return canvas.toDataURL("image/png")
    }

    // Generate different sizes
    const sizes = [72, 96, 128, 144, 152, 192, 384, 512]

    sizes.forEach((size) => {
      const dataUrl = generateIcon(size)

      // Create a link element to download (for development)
      const link = document.createElement("a")
      link.download = `icon-${size}.png`
      link.href = dataUrl

      // Uncomment to auto-download icons for development
      // link.click()
    })
  }, [])

  return null
}
