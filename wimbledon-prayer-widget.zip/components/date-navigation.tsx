"use client"

import { ChevronLeft, ChevronRight } from "lucide-react"

interface DateNavigationProps {
  currentDate: Date
  onDateChange: (date: Date) => void
  className?: string
}

export function DateNavigation({ currentDate, onDateChange, className = "" }: DateNavigationProps) {
  const goToPreviousDay = (): void => {
    const previousDay = new Date(currentDate)
    previousDay.setDate(previousDay.getDate() - 1)
    onDateChange(previousDay)
  }

  const goToNextDay = (): void => {
    const nextDay = new Date(currentDate)
    nextDay.setDate(nextDay.getDate() + 1)
    onDateChange(nextDay)
  }

  const formatDate = (date: Date): string => {
    try {
      return date.toLocaleDateString("en-GB", {
        weekday: "long",
        year: "numeric",
        month: "long",
        day: "numeric",
      })
    } catch (error) {
      console.error("Error formatting date:", error)
      return date.toString()
    }
  }

  return (
    <div className={`flex items-center justify-between ${className}`}>
      <button
        onClick={goToPreviousDay}
        className="p-2 rounded-full hover:bg-white/20 transition-colors focus:outline-none focus:ring-2 focus:ring-white/50"
        aria-label="Previous day"
      >
        <ChevronLeft className="h-5 w-5 text-white" />
      </button>

      <div className="text-center">
        <h2 className="text-lg font-semibold text-white leading-tight">{formatDate(currentDate)}</h2>
      </div>

      <button
        onClick={goToNextDay}
        className="p-2 rounded-full hover:bg-white/20 transition-colors focus:outline-none focus:ring-2 focus:ring-white/50"
        aria-label="Next day"
      >
        <ChevronRight className="h-5 w-5 text-white" />
      </button>
    </div>
  )
}
