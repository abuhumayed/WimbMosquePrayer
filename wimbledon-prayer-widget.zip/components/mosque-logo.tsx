"use client"

interface MosqueLogoProps {
  className?: string
  size?: "sm" | "md" | "lg"
}

export function MosqueLogo({ className = "", size = "md" }: MosqueLogoProps) {
  const sizeClasses = {
    sm: "w-8 h-8",
    md: "w-12 h-12",
    lg: "w-16 h-16",
  }

  return (
    <div className={`flex items-center ${className}`}>
      {/* Official Mosque Logo */}
      <div className={`${sizeClasses[size]} mr-3 flex items-center justify-center`}>
        <svg viewBox="0 0 120 120" className="w-full h-full">
          {/* Golden dome */}
          <path d="M60 18 C45 18 35 28 35 42 L85 42 C85 28 75 18 60 18 Z" fill="#F59E0B" />
          {/* Dome point */}
          <path d="M60 10 L52 25 L68 25 Z" fill="#F59E0B" />

          {/* White pillars */}
          <rect x="40" y="42" width="8" height="30" fill="#F3F4F6" stroke="#9CA3AF" strokeWidth="1" />
          <rect x="72" y="42" width="8" height="30" fill="#F3F4F6" stroke="#9CA3AF" strokeWidth="1" />

          {/* Green geometric base - W shape */}
          <path d="M25 72 L45 72 L55 92 L35 92 Z" fill="#10B981" />
          <path d="M75 72 L95 72 L85 92 L65 92 Z" fill="#10B981" />
          <path d="M52 82 L68 82 L65 92 L55 92 Z" fill="#10B981" />
        </svg>
      </div>

      {/* Text with system fonts */}
      <div className="flex flex-col">
        <span className="text-white font-bold text-lg leading-tight tracking-wide uppercase">WIMBLEDON</span>
        <span className="text-white/90 font-medium text-sm leading-tight tracking-wider">MOSQUE</span>
      </div>
    </div>
  )
}
