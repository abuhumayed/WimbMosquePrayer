export interface JumuahTimes {
  englishTalk: string
  jumuahPrayer: string
}

export function calculateJumuahTimes(zuhrJamatTime: string): JumuahTimes {
  try {
    // Parse the Zuhr Jamat time
    const parts = zuhrJamatTime.split(" ")
    if (parts.length < 2) {
      // Fallback for invalid format
      return {
        englishTalk: "12:30 PM",
        jumuahPrayer: "1:00 PM",
      }
    }

    const time = parts[0]
    const period = parts[1]

    const timeParts = time.split(":")
    if (timeParts.length !== 2) {
      // Fallback for invalid time format
      return {
        englishTalk: "12:30 PM",
        jumuahPrayer: "1:00 PM",
      }
    }

    const hours = Number.parseInt(timeParts[0], 10)
    const minutes = Number.parseInt(timeParts[1], 10)

    // Validate parsed numbers
    if (isNaN(hours) || isNaN(minutes)) {
      return {
        englishTalk: "12:30 PM",
        jumuahPrayer: "1:00 PM",
      }
    }

    // Convert to 24-hour format
    let hour24 = hours
    if (period === "PM" && hours !== 12) {
      hour24 += 12
    } else if (period === "AM" && hours === 12) {
      hour24 = 0
    }

    // Create Date object for Jumuah prayer time (same as Zuhr Jamat)
    const jumuahDate = new Date()
    jumuahDate.setHours(hour24, minutes, 0, 0)

    // Calculate English talk time (30 minutes before)
    const englishTalkDate = new Date(jumuahDate)
    englishTalkDate.setMinutes(englishTalkDate.getMinutes() - 30)

    // Format times back to 12-hour format
    const formatTime = (date: Date): string => {
      return date.toLocaleTimeString("en-US", {
        hour: "numeric",
        minute: "2-digit",
        hour12: true,
      })
    }

    return {
      englishTalk: formatTime(englishTalkDate),
      jumuahPrayer: formatTime(jumuahDate),
    }
  } catch (error) {
    console.error("Error calculating Jumuah times:", error)
    // Return fallback times
    return {
      englishTalk: "12:30 PM",
      jumuahPrayer: "1:00 PM",
    }
  }
}
