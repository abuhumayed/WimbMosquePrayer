"use client"

import { useState, useEffect, useMemo } from "react"
import { Clock, Calendar, Users } from "lucide-react"
import { ThemeToggle } from "@/components/theme-toggle"
import { DateNavigation } from "@/components/date-navigation"
import { MosqueLogo } from "@/components/mosque-logo"
import { InstallPrompt } from "@/components/install-prompt"
import { FontLoader } from "@/components/font-loader"
import { getPrayerTimes, getJumuahSchedule, type PrayerTimeEntry } from "@/lib/prayer-calendar"

export default function PrayerTimesWidget(): JSX.Element {
  const [currentDate, setCurrentDate] = useState(new Date())
  const [isDarkMode, setIsDarkMode] = useState(false)
  const [currentTime, setCurrentTime] = useState(new Date())
  const [mounted, setMounted] = useState(false)

  // Handle hydration
  useEffect(() => {
    setMounted(true)

    // Debug PWA capabilities
    console.log("PWA Debug Info:")
    console.log("- Service Worker supported:", "serviceWorker" in navigator)
    console.log("- Manifest supported:", "manifest" in document.createElement("link"))
    console.log("- Display mode:", window.matchMedia("(display-mode: standalone)").matches ? "standalone" : "browser")
    console.log("- User agent:", navigator.userAgent)
  }, [])

  // Update current time every second
  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentTime(new Date())
    }, 1000)

    return () => clearInterval(timer)
  }, [])

  // Get prayer times for current date
  const dateKey = useMemo(() => {
    return currentDate.toISOString().split("T")[0]
  }, [currentDate])

  const prayerTimes: PrayerTimeEntry | null = useMemo(() => {
    return getPrayerTimes(dateKey)
  }, [dateKey])

  // Calculate Jumuah times
  const jumuahSchedule = useMemo(() => {
    if (!prayerTimes) return null
    return getJumuahSchedule(dateKey)
  }, [prayerTimes, dateKey])

  // Check if current date is Friday
  const isFriday = useMemo(() => {
    return currentDate.getDay() === 5
  }, [currentDate])

  // Update the formatTime function to handle potential errors:
  const formatTime = (time: string): string => {
    try {
      if (!time || typeof time !== "string") {
        return "N/A"
      }

      // Convert 24-hour format to 12-hour format
      const timeParts = time.split(":")
      if (timeParts.length !== 2) {
        return time // Return original if format is unexpected
      }

      const hours = timeParts[0]
      const minutes = timeParts[1]
      const hour = Number.parseInt(hours, 10)

      if (isNaN(hour)) {
        return time // Return original if parsing fails
      }

      const ampm = hour >= 12 ? "PM" : "AM"
      const displayHour = hour === 0 ? 12 : hour > 12 ? hour - 12 : hour
      return `${displayHour}:${minutes} ${ampm}`
    } catch (error) {
      console.error("Error formatting time:", error)
      return time || "N/A"
    }
  }

  // Update the formatCurrentTime function:
  const formatCurrentTime = (): string => {
    if (!mounted) return "00:00:00 AM"

    try {
      return currentTime.toLocaleTimeString("en-US", {
        hour: "2-digit",
        minute: "2-digit",
        second: "2-digit",
        hour12: true,
      })
    } catch (error) {
      console.error("Error formatting current time:", error)
      return "00:00:00 AM"
    }
  }

  // Show loading state during hydration
  if (!mounted) {
    return (
      <>
        <FontLoader />
        <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 dark:from-gray-900 dark:to-gray-800 p-4 transition-colors duration-300">
          <div className="max-w-md mx-auto">
            <div className="bg-white dark:bg-gray-800 rounded-2xl shadow-xl p-6 transition-colors duration-300">
              <div className="animate-pulse">
                <div className="h-8 bg-gray-200 dark:bg-gray-700 rounded mb-4"></div>
                <div className="h-4 bg-gray-200 dark:bg-gray-700 rounded mb-2"></div>
                <div className="h-4 bg-gray-200 dark:bg-gray-700 rounded"></div>
              </div>
            </div>
          </div>
        </div>
      </>
    )
  }

  if (!prayerTimes) {
    return (
      <>
        <FontLoader />
        <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 dark:from-gray-900 dark:to-gray-800 p-4 transition-colors duration-300">
          <div className="max-w-md mx-auto">
            <div className="bg-white dark:bg-gray-800 rounded-2xl shadow-xl p-6 transition-colors duration-300">
              <div className="flex justify-between items-center mb-6">
                <h1 className="text-xl font-bold text-gray-900 dark:text-white">Prayer Times</h1>
                <ThemeToggle onThemeChange={setIsDarkMode} />
              </div>

              <DateNavigation currentDate={currentDate} onDateChange={setCurrentDate} className="mb-6" />

              <div className="text-center py-8">
                <p className="text-gray-600 dark:text-gray-300">Prayer times not available for this date.</p>
                <p className="text-sm text-gray-500 dark:text-gray-400 mt-2">Date: {dateKey}</p>
              </div>
            </div>
          </div>
          <InstallPrompt />
        </div>
      </>
    )
  }

  return (
    <>
      <FontLoader />
      <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 dark:from-gray-900 dark:to-gray-800 p-4 transition-colors duration-300">
        <div className="max-w-md mx-auto">
          <div className="bg-white dark:bg-gray-800 rounded-2xl shadow-xl overflow-hidden transition-colors duration-300">
            {/* Header with Mosque Branding */}
            <div className="bg-gradient-to-r from-emerald-600 via-green-600 to-teal-600 dark:from-emerald-700 dark:via-green-700 dark:to-teal-700 p-6 text-white relative overflow-hidden">
              {/* Background Pattern */}
              <div className="absolute inset-0 opacity-10">
                <div className="absolute top-0 left-0 w-full h-full bg-gradient-to-br from-white/20 to-transparent"></div>
                <div className="absolute -top-4 -right-4 w-24 h-24 bg-white/10 rounded-full"></div>
                <div className="absolute -bottom-6 -left-6 w-32 h-32 bg-white/5 rounded-full"></div>
              </div>

              <div className="relative z-10">
                <div className="flex justify-between items-start mb-4">
                  <a
                    href="https://wimbledonmosque.org"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="hover:scale-105 transition-transform duration-200"
                  >
                    <MosqueLogo size="md" />
                  </a>
                  <ThemeToggle onThemeChange={setIsDarkMode} />
                </div>

                <DateNavigation currentDate={currentDate} onDateChange={setCurrentDate} className="mb-4" />

                <div className="text-center">
                  <div className="flex items-center justify-center space-x-2 mb-2">
                    <Clock className="h-5 w-5" />
                    <span className="text-2xl font-mono font-bold tracking-wider">{formatCurrentTime()}</span>
                  </div>
                  <div className="text-white/80 text-sm font-medium">Live Prayer Times</div>
                </div>
              </div>
            </div>

            {/* Prayer Times */}
            <div className="p-6">
              <div className="space-y-4">
                {/* Regular Prayer Times */}
                <div className="grid grid-cols-2 gap-4">
                  <div className="text-center p-4 bg-gradient-to-br from-gray-50 to-gray-100 dark:from-gray-700 dark:to-gray-600 rounded-xl transition-colors duration-300 shadow-sm">
                    <div className="text-sm font-semibold text-gray-600 dark:text-gray-300 mb-1">Fajr</div>
                    <div className="text-lg font-bold text-gray-900 dark:text-white mb-1">
                      {formatTime(prayerTimes.fajr.begins)}
                    </div>
                    <div className="text-xs text-emerald-600 dark:text-emerald-400 font-medium">
                      Jamat: {formatTime(prayerTimes.fajr.jamat)}
                    </div>
                  </div>

                  <div className="text-center p-4 bg-gradient-to-br from-gray-50 to-gray-100 dark:from-gray-700 dark:to-gray-600 rounded-xl transition-colors duration-300 shadow-sm">
                    <div className="text-sm font-semibold text-gray-600 dark:text-gray-300 mb-1">Sunrise</div>
                    <div className="text-lg font-bold text-gray-900 dark:text-white">
                      {formatTime(prayerTimes.sunrise)}
                    </div>
                  </div>

                  <div className="text-center p-4 bg-gradient-to-br from-gray-50 to-gray-100 dark:from-gray-700 dark:to-gray-600 rounded-xl transition-colors duration-300 shadow-sm">
                    <div className="text-sm font-semibold text-gray-600 dark:text-gray-300 mb-1">Zuhr</div>
                    <div className="text-lg font-bold text-gray-900 dark:text-white mb-1">
                      {formatTime(prayerTimes.zuhr.begins)}
                    </div>
                    <div className="text-xs text-emerald-600 dark:text-emerald-400 font-medium">
                      Jamat: {formatTime(prayerTimes.zuhr.jamat)}
                    </div>
                  </div>

                  <div className="text-center p-4 bg-gradient-to-br from-gray-50 to-gray-100 dark:from-gray-700 dark:to-gray-600 rounded-xl transition-colors duration-300 shadow-sm">
                    <div className="text-sm font-semibold text-gray-600 dark:text-gray-300 mb-1">Asr</div>
                    <div className="text-lg font-bold text-gray-900 dark:text-white mb-1">
                      {formatTime(prayerTimes.asr.begins)}
                    </div>
                    <div className="text-xs text-emerald-600 dark:text-emerald-400 font-medium">
                      Jamat: {formatTime(prayerTimes.asr.jamat)}
                    </div>
                  </div>

                  <div className="text-center p-4 bg-gradient-to-br from-gray-50 to-gray-100 dark:from-gray-700 dark:to-gray-600 rounded-xl transition-colors duration-300 shadow-sm">
                    <div className="text-sm font-semibold text-gray-600 dark:text-gray-300 mb-1">Maghrib</div>
                    <div className="text-lg font-bold text-gray-900 dark:text-white mb-1">
                      {formatTime(prayerTimes.maghrib.begins)}
                    </div>
                    <div className="text-xs text-emerald-600 dark:text-emerald-400 font-medium">
                      Jamat: {formatTime(prayerTimes.maghrib.jamat)}
                    </div>
                  </div>

                  <div className="text-center p-4 bg-gradient-to-br from-gray-50 to-gray-100 dark:from-gray-700 dark:to-gray-600 rounded-xl transition-colors duration-300 shadow-sm">
                    <div className="text-sm font-semibold text-gray-600 dark:text-gray-300 mb-1">Isha</div>
                    <div className="text-lg font-bold text-gray-900 dark:text-white mb-1">
                      {formatTime(prayerTimes.isha.begins)}
                    </div>
                    <div className="text-xs text-emerald-600 dark:text-emerald-400 font-medium">
                      Jamat: {formatTime(prayerTimes.isha.jamat)}
                    </div>
                  </div>
                </div>

                {/* Jumuah Times (Friday only) */}
                {isFriday && jumuahSchedule && (
                  <div className="mt-6 p-5 bg-gradient-to-r from-amber-50 via-orange-50 to-yellow-50 dark:from-amber-900/20 dark:via-orange-900/20 dark:to-yellow-900/20 rounded-xl border-2 border-amber-200 dark:border-amber-700 transition-colors duration-300 shadow-sm">
                    <div className="flex items-center justify-center mb-4">
                      <Users className="h-6 w-6 text-amber-600 dark:text-amber-400 mr-2" />
                      <h3 className="text-xl font-bold text-amber-800 dark:text-amber-200">Jumuah Prayer</h3>
                    </div>

                    <div className="grid grid-cols-2 gap-3">
                      <div className="text-center p-3 bg-white dark:bg-gray-800 rounded-lg shadow-sm border border-amber-100 dark:border-amber-800">
                        <div className="text-sm font-semibold text-gray-600 dark:text-gray-300 mb-1">English Talk</div>
                        <div className="text-lg font-bold text-amber-700 dark:text-amber-300">
                          {jumuahSchedule.englishTalk}
                        </div>
                      </div>

                      <div className="text-center p-3 bg-white dark:bg-gray-800 rounded-lg shadow-sm border border-amber-100 dark:border-amber-800">
                        <div className="text-sm font-semibold text-gray-600 dark:text-gray-300 mb-1">Jumuah Prayer</div>
                        <div className="text-lg font-bold text-amber-700 dark:text-amber-300">
                          {jumuahSchedule.khutbaAndPrayer}
                        </div>
                      </div>
                    </div>

                    <div className="text-center mt-3">
                      <span className="text-xs text-amber-600 dark:text-amber-400 font-medium px-3 py-1 bg-amber-100 dark:bg-amber-900/30 rounded-full">
                        {jumuahSchedule.season}
                      </span>
                    </div>
                  </div>
                )}
              </div>
            </div>

            {/* Footer */}
            <div className="px-6 pb-6">
              <div className="text-center text-sm text-gray-500 dark:text-gray-400 bg-gray-50 dark:bg-gray-700 rounded-lg p-3">
                <div className="flex items-center justify-center space-x-1 mb-1">
                  <Calendar className="h-4 w-4" />
                  <span className="font-medium">Wimbledon Mosque Prayer Times</span>
                </div>
                <p className="text-xs">Last updated: {new Date().toLocaleDateString()}</p>
                <a
                  href="https://wimbledonmosque.org"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-emerald-600 dark:text-emerald-400 hover:underline text-xs font-medium mt-1 inline-block"
                >
                  Visit wimbledonmosque.org
                </a>
              </div>
            </div>
          </div>
        </div>

        {/* Install Prompt */}
        <InstallPrompt />
      </div>
    </>
  )
}
