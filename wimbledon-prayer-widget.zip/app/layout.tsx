import type React from "react"
import type { Metadata } from "next"
import "./globals.css"

export const metadata: Metadata = {
  title: "Wimbledon Prayer Times App",
  description: "Official Wimbledon Mosque prayer times and Jumuah schedule",
  manifest: "/manifest.json",
  themeColor: "#059669",
  appleWebApp: {
    capable: true,
    statusBarStyle: "default",
    title: "WimbledonPrayers",
  },
  icons: {
    icon: [
      { url: "/prayer-app-192.png", sizes: "192x192", type: "image/png" },
      { url: "/prayer-app-512.png", sizes: "512x512", type: "image/png" },
    ],
    apple: [{ url: "/prayer-app-icon.png", sizes: "180x180", type: "image/png" }],
    shortcut: "/prayer-app-icon.png",
  },
    generator: 'v0.dev'
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="en">
      <head>
        {/* Force cache refresh */}
        <meta httpEquiv="Cache-Control" content="no-cache, no-store, must-revalidate" />
        <meta httpEquiv="Pragma" content="no-cache" />
        <meta httpEquiv="Expires" content="0" />

        {/* PWA Meta Tags */}
        <meta name="application-name" content="WimbledonPrayers" />
        <meta name="apple-mobile-web-app-capable" content="yes" />
        <meta name="apple-mobile-web-app-status-bar-style" content="default" />
        <meta name="apple-mobile-web-app-title" content="WimbledonPrayers" />
        <meta name="format-detection" content="telephone=no" />
        <meta name="mobile-web-app-capable" content="yes" />
        <meta name="msapplication-TileColor" content="#059669" />
        <meta name="msapplication-tap-highlight" content="no" />
        <meta name="theme-color" content="#059669" />

        {/* New Icons with cache busting */}
        <link rel="icon" href="/prayer-app-icon.png?v=4" />
        <link rel="icon" type="image/png" sizes="192x192" href="/prayer-app-192.png?v=4" />
        <link rel="icon" type="image/png" sizes="512x512" href="/prayer-app-512.png?v=4" />
        <link rel="apple-touch-icon" href="/prayer-app-icon.png?v=4" />
        <link rel="apple-touch-icon" sizes="180x180" href="/prayer-app-icon.png?v=4" />

        {/* Manifest with cache busting */}
        <link rel="manifest" href="/manifest.json?v=4" />

        {/* Service Worker */}
        <script
          dangerouslySetInnerHTML={{
            __html: `
              if ('serviceWorker' in navigator) {
                window.addEventListener('load', function() {
                  navigator.serviceWorker.register('/sw.js?v=4')
                    .then(function(registration) {
                      console.log('SW registered: ', registration);
                    })
                    .catch(function(registrationError) {
                      console.log('SW registration failed: ', registrationError);
                    });
                });
              }
            `,
          }}
        />
      </head>
      <body className="font-sans antialiased">{children}</body>
    </html>
  )
}
