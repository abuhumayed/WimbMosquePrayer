const CACHE_NAME = "wimbledon-prayers-v4"
const urlsToCache = [
  "/",
  "/?installed=true&source=homescreen&v=4",
  "/manifest.json",
  "/prayer-app-192.png",
  "/prayer-app-512.png",
  "/prayer-app-icon.png",
]

self.addEventListener("install", (event) => {
  console.log("Prayer App SW v4 installing...")
  event.waitUntil(
    caches.open(CACHE_NAME).then((cache) => {
      console.log("Caching prayer app resources v4")
      return cache.addAll(urlsToCache)
    }),
  )
  self.skipWaiting()
})

self.addEventListener("activate", (event) => {
  console.log("Prayer App SW v4 activating...")
  event.waitUntil(
    caches.keys().then((cacheNames) => {
      return Promise.all(
        cacheNames.map((cacheName) => {
          if (cacheName !== CACHE_NAME) {
            console.log("Deleting old cache:", cacheName)
            return caches.delete(cacheName)
          }
        }),
      )
    }),
  )
  self.clients.claim()
})

self.addEventListener("fetch", (event) => {
  event.respondWith(
    fetch(event.request).catch(() => {
      return caches.match(event.request)
    }),
  )
})
