import type React from "react"
// Add performance monitoring utilities
export const performanceMonitor = {
  startTime: 0,

  start(): void {
    this.startTime = performance.now()
  },

  end(label: string): void {
    const endTime = performance.now()
    console.log(`${label}: ${endTime - this.startTime}ms`)
  },

  measureRender(componentName: string, renderFn: () => React.ReactElement): React.ReactElement {
    this.start()
    const result = renderFn()
    this.end(`${componentName} render`)
    return result
  },
}

// Preload critical resources
export function preloadCriticalResources(): void {
  // Preload the prayer data
  import("./prayer-calendar")
    .then(() => {
      console.log("Prayer calendar preloaded")
    })
    .catch((error) => {
      console.error("Failed to preload prayer calendar:", error)
    })
}
